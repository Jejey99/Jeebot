exports.menu = (ucapan, pushName, ownerName, botName, tanggal, jam, runtime, prefix) => {
    return `${ucapan} ${pushName}

👑 Creator : ${ownerName}
🤖 Bot Name : ${botName}
📆 Tanggal : ${tanggal}
⌚ Jam : ${jam}
⏳ Runtime
${runtime}

• ${prefix}sticker
• ${prefix}swm *text | text*
• ${prefix}toimg
• ${prefix}kick @tag
• ${prefix}add 62855xxx
• ${prefix}group *open/close*
• ${prefix}setgcname *text*
• ${prefix}setgcdesk *text*
• ${prefix}hidetag *text*
• ${prefix}antilink *on/off*
• ${prefix}leave
• ${prefix}setexif *text | text*
• ${prefix}addlist *key@response*
• ${prefix}dellist *key*
• ${prefix}updatelist *key@response*
• ${prefix}resetlist
• ${prefix}list
• ${prefix}p
• ${prefix}setp
• ${prefix}changep
• ${prefix}delsetp
• ${prefix}d
• ${prefix}setd
• ${prefix}changed
• ${prefix}delsetd

*EXECUTE*
• $
• >
• =>
`
}


